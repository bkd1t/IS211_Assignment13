from flask import Flask, render_template, redirect, url_for, request, session
import requests
import json
from werkzeug.security import generate_password_hash, check_password_hash
import datetime
app = Flask(__name__)
app.config['SECRET_KEY'] = 'configure strong secret key here'

@app.route('/')
def index():
    if ("username" not in session):
        return render_template('login.html')
    else:
        if (session["username"]!="admin"):
            return render_template('login.html', message="Invalid Credentials")
        elif session["username"]=='admin':
            return redirect('/dashboard')
@app.route('/delete/student/<id>')
def delete_student(id):
    if ("username" in session):
        if session["username"]=='admin':
            con = sqlite3.connect("hw13.db")
            try:
                with con:
                    cur = con.cursor()
                    cur.execute('DELETE from quiz_result where sid=?', ( id,))
                    cur.execute('DELETE from student where id=?', ( id,))
                    con.commit()
                    return redirect('/dashboard')
            except:
                return redirect('/dashboard')
        return redirect('/login', message="Please login")

@app.route('/delete/quiz/<id>')
def delete_quiz(id):
    if ("username" in session):
        if session["username"]=='admin':
            con = sqlite3.connect("hw13.db")
            try:
                with con:
                    cur = con.cursor()
                    cur.execute('DELETE from quiz_result where qid=?', ( id,))
                    cur.execute('DELETE from quiz where id=?', ( id,))
                    con.commit()
                    return redirect('/dashboard')
            except:
                return redirect('/dashboard')
        return redirect('/login', message="Please login")
@app.route('/delete/quiz_result/<id>')
def delete_quiz_result(id):
    if ("username" in session):
        if session["username"]=='admin':
            con = sqlite3.connect("hw13.db")
            try:
                with con:
                    cur = con.cursor()
                    cur.execute('DELETE from quiz_result where rid=?', ( id,))
                    con.commit()
                    return redirect('/dashboard')
            except:
                return redirect('/dashboard')
        return redirect('/login', message="Please login")

@app.route('/add/student', methods = ['POST', 'GET'])
def add_student():
    if ("username" in session):
        if session["username"]=='admin':
            if request.method == 'POST':
                fname = request.form['fname']
                lname = request.form['lname']
                print fname
                print lname
                con = sqlite3.connect("hw13.db")
                with con:
                    cur = con.cursor()
                    cur.execute('INSERT INTO student( firstname, lastname) VALUES(?, ?)', ( fname, lname))
                    con.commit()
                    return redirect('/dashboard')
            return render_template('add_student.html')
    else:
        return render_template('login.html', message="Please Login as admin")
@app.route('/student/<id>', methods=['GET'])
def view_student(id):
    if ("username" in session):
        con = sqlite3.connect("hw13.db")
        with con:
            cur = con.cursor()
            rows = cur.execute('SELECT rid,subject, grade, firstname, lastname FROM quiz_result, quiz, student where sid=? and sid=student.id and qid=quiz.id', ( id,))
            results = rows.fetchall()
            
            if (len(results)==0):
                message = ""
                return render_template('student_results.html', message=False, sid=id)
            name = results[0][3] + " " + results[0][4]
            return render_template('student_results.html', message=True, results=results,sid=id, name=name)
    return render_template('login.html', message="Please Login ")
    
@app.route('/quiz/<id>/results/', methods=['GET'])
def quiz_results(id):
    con = sqlite3.connect("hw13.db")
    with con:
        cur = con.cursor()
        rows = cur.execute('SELECT quiz.id,  subject, sid,grade FROM student,quiz_result, quiz where sid=student.id and quiz.id=? and qid=quiz.id', ( id,))
        results = rows.fetchall()
        if (len(results)==0):
            message = ""
            return render_template('anon_results.html', message=False)
        return render_template('anon_results.html', message=True,subject=results[0][1], results=results)

@app.route('/add/quiz', methods=['POST', 'GET'])
def add_quiz():
    if ("username" in session):
        if session["username"]=='admin':
            if request.method == 'POST':
                sub = request.form['sub']
                num = request.form['num']
                qdate = request.form['qdate']

                print sub
                print qdate
                print num
                con = sqlite3.connect("hw13.db")
                with con:
                    cur = con.cursor()
                    cur.execute('INSERT INTO quiz( subject,no_of_questions, quiz_date) VALUES(?, ?, ?)', ( sub, num, qdate))
                    con.commit()
                    return redirect('/dashboard')
            return render_template('add_quiz.html')
    else:
        return render_template('login.html', message="Please Login as admin")

@app.route('/results/add', methods=['POST', 'GET'])
def add_quiz_result():
    if ("username" in session):
        if session["username"]=='admin':
            if request.method == 'POST':
                sid = request.form['student']
                qid = request.form['quiz']
                grade = request.form['grade']

                print sid
                print qid
                print grade
                con = sqlite3.connect("hw13.db")
                with con:
                    cur = con.cursor()
                    cur.execute('INSERT INTO quiz_result( sid, qid, grade) VALUES(?, ?, ?)', ( sid, qid, grade))
                    con.commit()
                    return redirect('/dashboard')
            else:
                con = sqlite3.connect("hw13.db")
                with con:
                    cur = con.cursor()
                    rows = cur.execute('SELECT * from quiz')
                    qrows = rows.fetchall()
                    rows = cur.execute('SELECT * from student')
                    srows = rows.fetchall()
                    con.commit()
                return render_template('add_result.html', srows=srows, qrows=qrows)
            return render_template('add_result.html')
    else:
        return render_template('login.html', message="Please Login as admin")
@app.route('/dashboard')
def dashboard():
    if ("username" in session):
        if(session["username"]=="admin"):
            con = sqlite3.connect("hw13.db")
            with con:
                cur = con.cursor()
                rows = cur.execute('SELECT * from student')
                srows = rows.fetchall()
                rows = cur.execute('SELECT * from quiz')
                qrows = rows.fetchall()
                return render_template("dashboard.html", students=srows, quizzes=qrows)
    else:
        return render_template('login.html', message="Invalid Credentials")
    return render_template('login.html')
@app.route('/signup', methods = ['POST', 'GET'])
def singup():
    if not request.json:
        print "Test"
    item = request.json
    username = item["username"]
    password = item["password"]
    print(username)
    print(password)
    hashed_pwd = generate_password_hash(password, 'sha256')
    print(hashed_pwd)
    con = sqlite3.connect("hw13.db")
    with con:
        cur = con.cursor()
        cur.execute('INSERT INTO users( username, password) VALUES(?, ?)', ( username, hashed_pwd))
        con.commit()
        return json.dumps({"message": "success"})

@app.route('/query', methods = ['POST', 'GET'])
def query():
    con = sqlite3.connect("hw13.db")
    with con:
        cur = con.cursor()
        fn = "John"
        ln = "Smith"
        qn = "Python Basics"
        num = 5
        qdate = (datetime.date(2015,2,5),)
        # cur.execute('INSERT INTO student( firstname, lastname) VALUES(?, ?)', ( fn, ln))
        # cur.execute('INSERT INTO quiz( subject, no_of_questions, quiz_date) VALUES(?, ?, ?)', ( qn, num, '2015-02-05'))
        # cur.execute('INSERT INTO quiz_result( sid, qid) VALUES(?, ?)', ( 1, 1))

        cur.execute('Drop table quiz_result ')
        con.commit()
        return json.dumps({"message": "success"})

@app.route('/login', methods = ['POST', 'GET'])
def login():
    if not request.json:
        print "Test"
    item = request.json
    username = item["username"]
    password = item["password"]
    print username
    print password
    con = sqlite3.connect("hw13.db")
    with con:
        cur = con.cursor()
        rows = cur.execute('SELECT password from users where username=?',(username,))
        try:
            hashed_pwd = rows.fetchall()[0][0]
            print hashed_pwd
        except:
            return json.dumps({"message": "Invalid Credentials"})
        if check_password_hash(hashed_pwd, password) == True:
            session['username'] = username
            return json.dumps({"message":"success","username": session["username"]})
        else:
            return json.dumps({"message": "Invalid Credentials"})
        return json.dumps({"message": "Please Register before loggin in"})

if __name__=='__main__':
    import sqlite3
    conn = sqlite3.connect('hw13.db')
    conn.execute('CREATE table if not exists student (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, firstname varchar NOT NULL, lastname varchar NOT NULL)')
    conn.execute('CREATE table if not exists users (username  varchar PRIMARY KEY NOT NULL, password varchar NOT NULL)')
    conn.execute('CREATE table if not exists quiz (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, subject varchar NOT NULL, no_of_questions INTEGER, quiz_date DATE )')
    conn.execute('CREATE table if not exists quiz_result (rid INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, sid INTEGER NOT NULL, qid INTEGER NOT NULL, grade INTEGER NOT NULL, FOREIGN KEY(sid) REFERENCES student(id), FOREIGN KEY(qid) REFERENCES quiz(id))')
    conn.close()
    app.run()
